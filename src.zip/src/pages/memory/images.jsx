import React from "react";

const MemoryImages = () => {
  return <div>MemoryImages</div>;
  
};

export default MemoryImages;
